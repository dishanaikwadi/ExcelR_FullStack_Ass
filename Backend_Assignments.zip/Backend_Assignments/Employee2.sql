Create Database EMSystem;
use EMSystem;
create table DEPT (
	Deptno int primary key,
    Dname varchar(50),
    LOC varchar(50)
);
insert into DEPT(Deptno,Dname,LOC)
VALUES
	(10,'Software Development','Pune'),
    (20,'Research','Mumbai'),
    (30,'IT','Banglore'),
    (40,'Networking','Pune');
CREATE TABLE EMP (
    EMPNO INT PRIMARY KEY,
    ENAME VARCHAR(50),
    JOB VARCHAR(50),
    HIREDATE DATE,
    MGR INT,
    SAL DECIMAL(10, 2),
    COMM DECIMAL(10, 2),
    DEPTNO INT,
    FOREIGN KEY (DEPTNO) REFERENCES DEPT(DEPTNO)
);
INSERT INTO EMP (EMPNO, ENAME, JOB, HIREDATE, MGR, SAL, COMM, DEPTNO)
VALUES
    (7369, 'SMITH', 'CLERK', '1980-12-17', 7902, 800, NULL, 20),
    (7499, 'ALLEN', 'SALESMAN', '1981-02-20', 7698, 1600, 300, 30),
    (7521, 'WARD', 'SALESMAN', '1981-02-22', 7698, 1250, 500, 30),
    (7566, 'JONES', 'MANAGER', '1981-04-02', 7839, 2975, NULL, 20),
    (7654, 'MARTIN', 'SALESMAN', '1981-09-28', 7698, 1250, 1400, 30),
    (7698, 'BLAKE', 'MANAGER', '1981-05-01', 7839, 2850, NULL, 30),
    (7782, 'CLARK', 'MANAGER', '1981-06-09', 7839, 2450, NULL, 10),
    (7788, 'SCOTT', 'ANALYST', '1987-04-19', 7566, 3000, NULL, 20),
    (7839, 'KING', 'PRESIDENT', '1981-11-17', NULL, 5000, NULL, 10),
    (7844, 'TURNER', 'SALESMAN', '1981-09-08', 7698, 1500, 0, 30),
    (7900, 'ADAMS', 'CLERK', '1987-05-23', 7788, 1500, NULL, 20),
    (7902, 'FORD', 'ANALYST', '1981-12-03', 7566, 950, NULL, 10),
    (7934, 'MILLER', 'CLERK', '1982-01-23', 7782, 1300, NULL, 10);


Drop table EMP;

select ename,job, (sal/2) as half_term_salary
from emp;

select*, (sal * 12) + 2000 as Annual_With_Bonus
from emp;

select ename, sal, (sal * 1.10) As Salary_After_Hike
from emp;

select ename, sal, (SAL * 0.75) As Salary_After_Deduction
from emp;

select ename,hiredate
from emp
where hiredate between '1982-01-01' AND '1982-12-31';

select ename
from emp
where comm is not null AND comm > 0;

select ename
from emp
where ename like '_A%';

select deptno,AVG(Sal) As Avg_salary
From emp
where Deptno!=20
group by deptno;

select job, COUNT(*) as count_emp
from emp
where lower(ename) like '%a%'
group by job;

select deptno,max(sal) as max_salary
from emp
group by deptno;

select ename,job
from emp
where job= (select job from emp where ename = 'JAMES');

select ename,hiredate
from emp
where ename like '%S' AND Hiredate > (select hiredate from emp where ename='JAMES');



