import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CollectionManagementSystem {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CollectionManagementGUI().setVisible(true));
    }
}

class CollectionManagementGUI extends JFrame {
    private List<String> listCollection;
    private Set<String> setCollection;

    public CollectionManagementGUI() {
        setTitle("Collection Management System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        listCollection = new ArrayList<>();
        setCollection = new HashSet<>();

        initializeUI();
    }

    private void initializeUI() {
        JPanel panel = new JPanel(new GridLayout(4, 1, 10, 10));

        JButton btnManageList = new JButton("Manage List");
        JButton btnManageSet = new JButton("Manage Set");
        JButton btnExit = new JButton("Exit");

        btnManageList.addActionListener(e -> manageList());
        btnManageSet.addActionListener(e -> manageSet());
        btnExit.addActionListener(e -> System.exit(0));

        panel.add(btnManageList);
        panel.add(btnManageSet);
        panel.add(btnExit);

        add(panel, BorderLayout.CENTER);
    }

    private void manageList() {
        Object[] options = {"Add Element", "Remove Element", "Display Elements"};
        int choice = JOptionPane.showOptionDialog(this, "Choose an operation for List", "Manage List",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        switch (choice) {
            case 0 -> addElementToList();
            case 1 -> removeElementFromList();
            case 2 -> displayListElements();
        }
    }

    private void addElementToList() {
        String element = JOptionPane.showInputDialog(this, "Enter element to add to the List:");
        if (element != null && !element.trim().isEmpty()) {
            listCollection.add(element);
            JOptionPane.showMessageDialog(this, "Element added successfully.");
        } else {
            JOptionPane.showMessageDialog(this, "Invalid input. Element cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void removeElementFromList() {
        String element = JOptionPane.showInputDialog(this, "Enter element to remove from the List:");
        if (element != null) {
            if (listCollection.remove(element)) {
                JOptionPane.showMessageDialog(this, "Element removed successfully.");
            } else {
                JOptionPane.showMessageDialog(this, "Element not found in the List.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void displayListElements() {
        if (listCollection.isEmpty()) {
            JOptionPane.showMessageDialog(this, "The List is empty.");
        } else {
            JOptionPane.showMessageDialog(this, "List Elements:\n" + String.join(", ", listCollection));
        }
    }

    private void manageSet() {
        Object[] options = {"Add Element", "Remove Element", "Display Elements"};
        int choice = JOptionPane.showOptionDialog(this, "Choose an operation for Set", "Manage Set",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        switch (choice) {
            case 0 -> addElementToSet();
            case 1 -> removeElementFromSet();
            case 2 -> displaySetElements();
        }
    }

    private void addElementToSet() {
        String element = JOptionPane.showInputDialog(this, "Enter element to add to the Set:");
        if (element != null && !element.trim().isEmpty()) {
            if (setCollection.add(element)) {
                JOptionPane.showMessageDialog(this, "Element added successfully.");
            } else {
                JOptionPane.showMessageDialog(this, "Duplicate element. Set does not allow duplicates.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Invalid input. Element cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void removeElementFromSet() {
        String element = JOptionPane.showInputDialog(this, "Enter element to remove from the Set:");
        if (element != null) {
            if (setCollection.remove(element)) {
                JOptionPane.showMessageDialog(this, "Element removed successfully.");
            } else {
                JOptionPane.showMessageDialog(this, "Element not found in the Set.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void displaySetElements() {
        if (setCollection.isEmpty()) {
            JOptionPane.showMessageDialog(this, "The Set is empty.");
        } else {
            JOptionPane.showMessageDialog(this, "Set Elements:\n" + String.join(", ", setCollection));
        }
    }
}
