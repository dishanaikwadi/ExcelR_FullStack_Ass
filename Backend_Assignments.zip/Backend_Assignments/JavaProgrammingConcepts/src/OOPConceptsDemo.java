import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Class and Object
class Person {
    private String name;
    private int age;

    // Class Constructor
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public void displayDetails() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}
class Calculator {
    public int add(int a, int b) {
        return a + b;
    }

    public double add(double a, double b) {
        return a + b;
    }

    public int subtract(int a, int b) {
        return a - b;
    }

    public int multiply(int a, int b) {
        return a * b;
    }

    public double divide(int a, int b) {
        if (b == 0) {
            throw new ArithmeticException("Division by zero is not allowed.");
        }
        return (double) a / b;
    }
}

// Inheritance
class Employee extends Person {
    private String department;

    public Employee(String name, int age, String department) {
        super(name, age);
        this.department = department;
    }

    public String getDepartment() {
        return department;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Department: " + department);
    }
}

// Abstract Class
abstract class Shape {
    public abstract void draw(); // Abstract method
}

// Interface
interface Drawable {
    void render();
}

// Implementation of Abstract Class and Interface
class Circle extends Shape implements Drawable {
    @Override
    public void draw() {
        System.out.println("Drawing Circle...");
    }

    @Override
    public void render() {
        System.out.println("Rendering Circle...");
    }
}



// Method Overriding (Example above in Employee class)
public class OOPConceptsDemo {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new OOPSExampleGUI().setVisible(true));
    }
}

class OOPSExampleGUI extends JFrame {
    public OOPSExampleGUI() {
        setTitle("OOPS Concepts in Java");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initializeUI();
    }

    private void initializeUI() {
        JPanel panel = new JPanel(new GridLayout(8, 1, 10, 10));

        JButton btnClassObject = new JButton("Class and Object");
        JButton btnConstructor = new JButton("Class Constructor");
        JButton btnOverloading = new JButton("Method Overloading");
        JButton btnOverriding = new JButton("Method Overriding");
        JButton btnInheritance = new JButton("Inheritance");
        JButton btnAbstractInterface = new JButton("Abstract Class & Interface");
        JButton btnCalculator = new JButton("Calculator");

        btnClassObject.addActionListener(e -> demoClassAndObject());
        btnConstructor.addActionListener(e -> demoConstructor());
        btnOverloading.addActionListener(e -> demoMethodOverloading());
        btnOverriding.addActionListener(e -> demoMethodOverriding());
        btnInheritance.addActionListener(e -> demoInheritance());
        btnAbstractInterface.addActionListener(e -> demoAbstractInterface());
        btnCalculator.addActionListener(e -> demoCalculator());

        panel.add(btnClassObject);
        panel.add(btnConstructor);
        panel.add(btnOverloading);
        panel.add(btnOverriding);
        panel.add(btnInheritance);
        panel.add(btnAbstractInterface);
        panel.add(btnCalculator);

        add(panel, BorderLayout.CENTER);
    }

    private void demoClassAndObject() {
        Person person = new Person("Alice", 25);
        JOptionPane.showMessageDialog(this, "Created Person: Name = " + person.getName() + ", Age = " + person.getAge());
    }

    private void demoConstructor() {
        JTextField nameField = new JTextField();
        JTextField ageField = new JTextField();

        Object[] message = {
            "Name:", nameField,
            "Age:", ageField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Enter Details for Person", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String name = nameField.getText();
            int age = Integer.parseInt(ageField.getText());
            Person person = new Person(name, age);
            JOptionPane.showMessageDialog(this, "Person Created: " + person.getName() + ", Age: " + person.getAge());
        }
    }

    private void demoMethodOverloading() {
        Calculator calc = new Calculator();
        int sumInt = calc.add(10, 20);
        double sumDouble = calc.add(5.5, 3.3);

        JOptionPane.showMessageDialog(this, "Method Overloading:\n" +
                "add(int, int): " + sumInt + "\n" +
                "add(double, double): " + sumDouble);
    }

    private void demoMethodOverriding() {
        Employee emp = new Employee("Bob", 30, "IT");
        JOptionPane.showMessageDialog(this, "Method Overriding:\n" +
                "Employee Details: Name = " + emp.getName() + ", Age = " + emp.getAge() + ", Department = " + emp.getDepartment());
    }

    private void demoInheritance() {
        Employee emp = new Employee("Charlie", 35, "Finance");
        JOptionPane.showMessageDialog(this, "Inheritance:\n" +
                "Employee Details: Name = " + emp.getName() + ", Age = " + emp.getAge() + ", Department = " + emp.getDepartment());
    }

    private void demoAbstractInterface() {
        Circle circle = new Circle();
        circle.draw();
        circle.render();

        JOptionPane.showMessageDialog(this, "Abstract Class and Interface:\n" +
                "Circle drawn and rendered successfully.");
    }

    private void demoCalculator() {
        JTextField num1Field = new JTextField();
        JTextField num2Field = new JTextField();
        String[] operations = {"Add", "Subtract", "Multiply", "Divide"};
        JComboBox<String> operationBox = new JComboBox<>(operations);

        Object[] message = {
            "Enter first number:", num1Field,
            "Enter second number:", num2Field,
            "Select operation:", operationBox
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Calculator", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int num1 = Integer.parseInt(num1Field.getText());
                int num2 = Integer.parseInt(num2Field.getText());
                String operation = (String) operationBox.getSelectedItem();
                Calculator calc = new Calculator();
                double result = 0;

                switch (operation) {
                    case "Add":
                        result = calc.add(num1, num2);
                        break;
                    case "Subtract":
                        result = calc.subtract(num1, num2);
                        break;
                    case "Multiply":
                        result = calc.multiply(num1, num2);
                        break;
                    case "Divide":
                        result = calc.divide(num1, num2);
                        break;
                }

                JOptionPane.showMessageDialog(this, "Result: " + result);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter valid numbers.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (ArithmeticException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

}  