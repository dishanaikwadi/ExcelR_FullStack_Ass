import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StringOperations {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new StringOperationsGUI().setVisible(true));
    }
}

class StringOperationsGUI extends JFrame {
    public StringOperationsGUI() {
        setTitle("String Operations");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initializeUI();
    }

    private void initializeUI() {
        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));

        JButton btnSubstring = new JButton("Extract Substring");
        JButton btnSplitSentence = new JButton("Split Sentence");
        JButton btnExit = new JButton("Exit");

        btnSubstring.addActionListener(e -> extractSubstring());
        btnSplitSentence.addActionListener(e -> splitSentence());
        btnExit.addActionListener(e -> System.exit(0));

        panel.add(btnSubstring);
        panel.add(btnSplitSentence);
        panel.add(btnExit);

        add(panel, BorderLayout.CENTER);
    }

    private void extractSubstring() {
        JTextField inputField = new JTextField();
        JTextField startIndexField = new JTextField();
        JTextField endIndexField = new JTextField();

        Object[] message = {
            "Enter a String:", inputField,
            "Start Index:", startIndexField,
            "End Index:", endIndexField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Extract Substring", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String inputString = inputField.getText();

            try {
                int startIndex = Integer.parseInt(startIndexField.getText());
                int endIndex = Integer.parseInt(endIndexField.getText());

                if (startIndex < 0 || endIndex > inputString.length() || startIndex >= endIndex) {
                    JOptionPane.showMessageDialog(this, "Invalid indices! Ensure start < end and within bounds.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    String substring = inputString.substring(startIndex, endIndex);
                    JOptionPane.showMessageDialog(this, "Extracted Substring: " + substring, "Result", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input for indices! Please enter numeric values.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void splitSentence() {
        JTextField sentenceField = new JTextField();

        Object[] message = {
            "Enter a Sentence:", sentenceField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Split Sentence", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String sentence = sentenceField.getText();

            if (sentence.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Input cannot be empty! Please enter a valid sentence.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                String[] words = sentence.split("\\s+");
                StringBuilder result = new StringBuilder("Split Words:\n");
                for (String word : words) {
                    result.append(word).append("\n");
                }
                JOptionPane.showMessageDialog(this, result.toString(), "Result", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
}
