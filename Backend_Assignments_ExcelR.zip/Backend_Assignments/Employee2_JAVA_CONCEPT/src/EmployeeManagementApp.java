import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EmployeeManagementApp {
    private EmployeeManager manager = new EmployeeManager();

    public EmployeeManagementApp() {
        JFrame frame = new JFrame("Employee Management System");
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Panels for Input and Output
        JPanel panel = new JPanel(new GridLayout(6, 2));
        JLabel lblId = new JLabel("Employee ID:");
        JTextField txtId = new JTextField();
        JLabel lblName = new JLabel("Name:");
        JTextField txtName = new JTextField();
        JLabel lblDepartment = new JLabel("Department:");
        JTextField txtDepartment = new JTextField();
        JLabel lblSalary = new JLabel("Salary:");
        JTextField txtSalary = new JTextField();

        panel.add(lblId);
        panel.add(txtId);
        panel.add(lblName);
        panel.add(txtName);
        panel.add(lblDepartment);
        panel.add(txtDepartment);
        panel.add(lblSalary);
        panel.add(txtSalary);

        JButton btnAdd = new JButton("Add");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");
        JButton btnView = new JButton("View All");
        JButton btnSearch = new JButton("Search");

        panel.add(btnAdd);
        panel.add(btnUpdate);
        panel.add(btnDelete);
        panel.add(btnView);
        panel.add(btnSearch);

        JTextArea output = new JTextArea();
        output.setEditable(false);

        frame.add(panel, BorderLayout.NORTH);
        frame.add(new JScrollPane(output), BorderLayout.CENTER);

        // Button Actions
        btnAdd.addActionListener(e -> {
            try {
                manager.addEmployee(new Employee(
                        txtId.getText(),
                        txtName.getText(),
                        txtDepartment.getText(),
                        Double.parseDouble(txtSalary.getText())
                ));
                output.setText("Employee added successfully.");
            } catch (Exception ex) {
                output.setText("Error: " + ex.getMessage());
            }
        });

        btnUpdate.addActionListener(e -> {
            try {
                manager.updateEmployee(
                        txtId.getText(),
                        txtName.getText(),
                        txtDepartment.getText(),
                        Double.parseDouble(txtSalary.getText())
                );
                output.setText("Employee updated successfully.");
            } catch (Exception ex) {
                output.setText("Error: " + ex.getMessage());
            }
        });

        btnDelete.addActionListener(e -> {
            try {
                manager.deleteEmployee(txtId.getText());
                output.setText("Employee deleted successfully.");
            } catch (Exception ex) {
                output.setText("Error: " + ex.getMessage());
            }
        });

        btnView.addActionListener(e -> output.setText(manager.getAllEmployees()));

        btnSearch.addActionListener(e -> {
            try {
                Employee emp = manager.getEmployee(txtId.getText());
                output.setText(emp.toString());
            } catch (Exception ex) {
                output.setText("Error: " + ex.getMessage());
            }
        });

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(EmployeeManagementApp::new);
    }
}
