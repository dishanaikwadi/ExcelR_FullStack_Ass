import java.util.HashMap;

public class EmployeeManager {
    private HashMap<String, Employee> employees = new HashMap<>();

    // Add Employee
    public void addEmployee(Employee employee) {
        if (employees.containsKey(employee.getId())) {
            throw new IllegalArgumentException("Employee ID already exists.");
        }
        employees.put(employee.getId(), employee);
    }

    // Update Employee
    public void updateEmployee(String id, String name, String department, double salary) {
        Employee emp = employees.get(id);
        if (emp == null) {
            throw new IllegalArgumentException("Employee not found.");
        }
        emp.setName(name);
        emp.setDepartment(department);
        emp.setSalary(salary);
    }

    // Delete Employee
    public void deleteEmployee(String id) {
        if (!employees.containsKey(id)) {
            throw new IllegalArgumentException("Employee not found.");
        }
        employees.remove(id);
    }

    // Get Employee
    public Employee getEmployee(String id) {
        Employee emp = employees.get(id);
        if (emp == null) {
            throw new IllegalArgumentException("Employee not found.");
        }
        return emp;
    }

    // Get All Employees
    public String getAllEmployees() {
        if (employees.isEmpty()) {
            return "No employees available.";
        }
        StringBuilder sb = new StringBuilder();
        for (Employee emp : employees.values()) {
            sb.append(emp.toString()).append("\n");
        }
        return sb.toString();
    }
}
