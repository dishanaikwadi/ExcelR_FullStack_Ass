import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class EmployeeManagement {
    static final String DB_URL = "jdbc:mysql://localhost:3306/employee_management_system";
    static final String DB_USER = "root";
    static final String DB_PASSWORD = "Vidisha@03";

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EmployeeManagementGUI().setVisible(true));
    }
}

class EmployeeManagementGUI extends JFrame {
    private Connection connection;

    public EmployeeManagementGUI() {
        setTitle("Employee Management System");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        connectToDatabase();
        initializeUI();
    }

    private void connectToDatabase() {
        try {
            connection = DriverManager.getConnection(EmployeeManagement.DB_URL, EmployeeManagement.DB_USER, EmployeeManagement.DB_PASSWORD);
            JOptionPane.showMessageDialog(this, "Connected to the database!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to connect to the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
    }

    private void initializeUI() {
        JPanel panel = new JPanel(new GridLayout(5, 1, 10, 10));
        JButton addButton = new JButton("Add Employee");
        JButton updateButton = new JButton("Update Employee");
        JButton deleteButton = new JButton("Delete Employee");
        JButton displayButton = new JButton("Display All Employees");
        JButton exitButton = new JButton("Exit");

        addButton.addActionListener(e -> addEmployee());
        updateButton.addActionListener(e -> updateEmployee());
        deleteButton.addActionListener(e -> deleteEmployee());
        displayButton.addActionListener(e -> displayEmployees());
        exitButton.addActionListener(e -> System.exit(0));

        panel.add(addButton);
        panel.add(updateButton);
        panel.add(deleteButton);
        panel.add(displayButton);
        panel.add(exitButton);

        add(panel, BorderLayout.CENTER);
    }

    private void addEmployee() {
        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField departmentField = new JTextField();
        JTextField salaryField = new JTextField();

        Object[] message = {
            "ID:", idField,
            "Name:", nameField,
            "Department:", departmentField,
            "Salary:", salaryField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Add Employee", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try (PreparedStatement stmt = connection.prepareStatement("INSERT INTO employees (id, name, department, salary) VALUES (?, ?, ?, ?)")) {
                stmt.setInt(1, Integer.parseInt(idField.getText()));
                stmt.setString(2, nameField.getText());
                stmt.setString(3, departmentField.getText());
                stmt.setDouble(4, Double.parseDouble(salaryField.getText()));
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Employee added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void updateEmployee() {
        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField departmentField = new JTextField();
        JTextField salaryField = new JTextField();

        Object[] message = {
            "Employee ID to Update:", idField,
            "New Name:", nameField,
            "New Department:", departmentField,
            "New Salary:", salaryField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Update Employee", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try (PreparedStatement stmt = connection.prepareStatement("UPDATE employees SET name = ?, department = ?, salary = ? WHERE id = ?")) {
                stmt.setString(1, nameField.getText());
                stmt.setString(2, departmentField.getText());
                stmt.setDouble(3, Double.parseDouble(salaryField.getText()));
                stmt.setInt(4, Integer.parseInt(idField.getText()));
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Employee updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void deleteEmployee() {
        JTextField idField = new JTextField();

        Object[] message = {
            "Employee ID to Delete:", idField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Delete Employee", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try (PreparedStatement stmt = connection.prepareStatement("DELETE FROM employees WHERE id = ?")) {
                stmt.setInt(1, Integer.parseInt(idField.getText()));
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Employee deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void displayEmployees() {
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM employees")) {
            StringBuilder employees = new StringBuilder("Employee Details:\n\n");
            while (rs.next()) {
                employees.append("ID: ").append(rs.getInt("id"))
                        .append(", Name: ").append(rs.getString("name"))
                        .append(", Department: ").append(rs.getString("department"))
                        .append(", Salary: ").append(rs.getDouble("salary")).append("\n");
            }
            JOptionPane.showMessageDialog(this, employees.toString(), "All Employees", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
