package com.excelr.employeepromax;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeepromaxApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeepromaxApplication.class, args);
	}

}
