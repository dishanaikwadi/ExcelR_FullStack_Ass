package com.excelr.employeepromax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeepromaxApplicationTests {

	@Test
	void contextLoads() {
	}

}
