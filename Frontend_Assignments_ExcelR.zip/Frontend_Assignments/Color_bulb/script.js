document.getElementById('onButton').addEventListener('click',function() {
    let color=prompt("Enter the bulb color:");
    if(color) {
        document.getElementById('bulb').style.backgroundColor=color;
    }
});
document.getElementById('offButton').addEventListener('click',function() {
    document.getElementById('bulb').style.backgroundColor='white';
});